Jasper's World — Guardrails Pack

Folder layout:
- docs/architecture: camera/rendering/parallax/layering contracts and technical stability specs
- docs/design: level design, progression, engagement, readability, enemy and movement intent
- docs/agents: AI usage contracts, context retention, regression process, implementation discipline
- docs/guardrails: misc or uncategorized items (should be minimal)

NOTE: These documents are intended to be used as Knowledge for agents.
If code and guardrails disagree, guardrails win until explicitly revoked.
